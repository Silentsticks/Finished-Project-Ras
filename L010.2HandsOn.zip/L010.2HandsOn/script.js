function myFunction() {
var x = document.getElementById("theEmail");
    if (x.style.display === "block") {
         x.style.display = "none";
    }  else {
        x.style.display = "block";
    }
    }
            


    function loadRepo(){
        const xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status
                == 200){
                    results = JSON.parse(this.responseText)
                    ;
                    document.getElementById("repo1")
                    .innerHTML = results [0].name;
                }
            }
            xhttp.open("GET", "https://api.github.com/users/Silentsticks/repos", true)
            xhttp.send();
    }